# ssho-reco-api
### numpy version Matrix Factorization(0808)
>numpy : 1.18.5
>input : dictionary, key = user.id, value = user.rating
>고정된 item list를 가정했을 때, main.py에서 ['item1' ~ 'item7']에서 상위 rating^ 가진 아이템 3개 반환
